#!/usr/bin/python
from importlib import reload
from selenium import webdriver
from bs4 import BeautifulSoup
from dateutil.rrule import DAILY, rrule, MO, TU, WE, TH, FR, SA, SU
from datetime import datetime, timedelta
import sys
from sqlalchemy import create_engine, Column, Integer, String, Text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.engine.url import URL
import settings
#from xvfbwrapper import Xvfb
import tempfile
import os
import logging
import time
import requests
import re


Base = declarative_base()

class Cases(Base):
    __tablename__ = 'cases'

    id = Column(Integer, primary_key=True)
    caseNumber = Column(String(100))
    county = Column(String(100))
    courtType = Column(String(100))
    date = Column(String(100))
    time = Column(String(100))
    roomNumber = Column(String(100))
    defendantName = Column(String(100))
    hearingType = Column(String(100))
    charges = Column(Text)

    def __init__(self, caseNumber, county, courtType, date, time, roomNumber, defendantName, hearingType, charges):
        self.caseNumber = caseNumber
        self.county = county
        self.courtType = courtType
        self.date = date
        self.time = time
        self.roomNumber = roomNumber
        self.defendantName = defendantName
        self.hearingType = hearingType
        self.charges = charges

    def __repr__(self):
        return "<Cases(%s, %s, %s, %s, %s, %s, %s, %s, %s)>" % (self.caseNumber, self.county, self.courtType, self.date, self.time, self.roomNumber, self.defendantName, self.hearingType, self.charges)

class Case(object):
    def __init__(self):
        self.caseNumber = ""
        self.county = ""
        self.courtType = ""
        self.date = ""
        self.time = ""
        self.roomNumber = ""
        self.defendantName = ""
        self.hearingType = ""
        self.charges = []

def main():

    logging.basicConfig(level=logging.INFO)

    logger = logging.getLogger(__name__)

    handler = logging.FileHandler('/home/ec2-user/environment/scraper_logs/scraper_kcoj_' + time.strftime("%d_%m_%Y") + '.log')

    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)


    logger.info('Initializing scraper...')

    engine = create_engine(URL(**settings.DATABASE), echo=False)
    Session = sessionmaker(bind=engine)
    session = Session()
    Base.metadata.create_all(engine)
    #refresh = session.query(Cases).all()
    #for record in refresh:
    #    session.delete(record)
    #session.commit()

    reload(sys)
    # sys.setdefaultencoding('utf-8')
    #vdisplay = Xvfb()
    #vdisplay.start()
    log_path = os.path.join(tempfile.mkdtemp(), 'ghostdriver.log')
    url = "http://kcoj.kycourts.net/dockets/Default.aspx"
    #driver = webdriver.Firefox()
    #driver = webdriver.PhantomJS(service_log_path=log_path)
    #driver.implicitly_wait(40)
    with requests.Session() as s:
        print(s.headers)
        s.headers.update({'Referer':'http://kcoj.kycourts.net/dockets/'})
        print(s.headers)
        resp = s.get(url)
    #driver.get(url)
    #html = driver.page_source
    soup = BeautifulSoup(resp.content)
    now = datetime.now()
    tomorrow = now + timedelta(days=1)
    days = [str("%02d/%d/%d" % (day.month, day.day, day.year)) for day in rrule(DAILY, dtstart=now, until=now, byweekday=(MO,TU,WE,TH,FR,SA,SU))]
    
    cases = []
    chargeKeys = ["TICS ", "TRAFFIC IN", "POSS", "CULTIVATION", "MANUFACTURING", "TRAFF", "SUBSTANCE", "INFL", "CONTROLLED SUBS"]
    counties = ["%s/%s" % (value['value'],value.string) for value in soup.find('select', {'id':"ContentPlaceHolder_Content_cmb_county_court"}).find_all('option', {'value':True}) if value['value'] != "0000"]

    logger.info('Scraper initialized!')

    try:
        for county in counties:
            for courtType in ["Circuit/CI", "District/DI"]:
                for day in days:

                    logger.info('I am inside day for days for cycle')

                    url = "http://kcoj.kycourts.net/dockets/Default.aspx?countyCourt=%s&division=%s&eventDate=%s&courtRoom=ALL&subDivision=ALL" % (county.split('/')[0], courtType.split('/')[1], day)
                    print('getting: ' + day)
                    logger.info('trying to get: '+ url)

                    flag1 = True
                    counter1 = 0

                    while (flag1):
                        try:
                            print(url)
                            with requests.Session() as s:
                                s.headers.update({'Referer':'http://kcoj.kycourts.net/dockets/'})
                                resp = s.get(url)
                                
                            with open('last_response_level1.html', 'w') as res1:
                                res1.write(url)
                                res1.write(str(resp.content.decode('ASCII', 'replace')))
                            # logger.info('Successful!')

                            if 'The wait operation timed out' in resp.text:
                                logger.info('An error in reading (level1), server error, operation timed out')
                                time.sleep(2)
                                counter1 = counter1 + 1
                                if counter1 > 10:
                                    logger.info('Failed')
                                    flag1 = False
                                    break
                                continue
                            
                            soup = BeautifulSoup(resp.content)
                            print('souped')
                            docket = soup.findAll('div', id=re.compile("Content_section_docket_data"))[0]
                            print('docketed')
                            #docket = driver.find_element_by_xpath("//div[contains(@id,'Content_section_docket_data')]")
                            flag1 = False
                        except Exception as e:
                            print(repr(e))
                            print(sys.exc_info()[0])
                            logger.info('An error in reading (level1), slow loading')
                            counter1 = counter1 + 1
                            if counter1 > 10:
                                logger.info('Failed')
                                flag1 = False

                    if "block" in docket["style"]:
                        numberOfPages = int(docket.find("label").text.split(' ')[-1])
                        print(docket.find("label").text.split(' '))
                        print(numberOfPages)
                        logger.info('Got the number of pages: ' + str(numberOfPages))

                        for j in range(numberOfPages):

                            logger.info('trying to get: ' + url + "&pageIndex=" + str(j+1))
                            print('getting page')
                            flag2 = True
                            counter2 = 0

                            while (flag2):
                                try:
                                    with requests.Session() as s:
                                        s.headers.update({'Referer':'http://kcoj.kycourts.net/dockets/'})
                                        resp = s.get(url + "&pageIndex=" + str(j + 1))
                                    #driver.get(url + "&pageIndex=" + str(j + 1))

                                    with open('last_response_level2.html', 'w') as res1:
                                        res1.write(url + "&pageIndex=" + str(j + 1))
                                        res1.write(resp.content.decode('ASCII', 'replace'))

                                    if 'The wait operation timed out' in resp.text:
                                        logger.info('An error in reading (level2), server error, operation timed out')
                                        time.sleep(2)
                                        counter2 = counter2 + 1
                                        if counter2 > 10:
                                            logger.info('Failed')
                                            flag2 = False
                                            break
                                        continue
                                    soup = BeautifulSoup(resp.content)     
                                    docket = soup.find('div', id=re.compile("Content_section_docket_data"))
                                    sections = docket.find_all(recursive=False)
                                    flag2 = False
                                except:
                                    logger.info('An error in reading (level2), slow responce')
                                    counter2 = counter2 + 1
                                    if counter2 > 10:
                                        logger.info('Failed')
                                        flag2 = False

                            for section in sections[1:-1]:

                                logger.info('sections iteration')

                                roomNumber = section.find_all("label")[1].text
                                trials = section.find('div', {'style': 'margin-left:15px; margin-right:15px;'}).find_all(recursive=False)
                                trialTime = ""
                                for i,trial in enumerate(trials):
                                    if not i % 2:
                                        trialTime = trial.find("label").text
                                    else:
                                        actualCases = trial.find_all(recursive=False)
                                        for actualCase in actualCases:
                                            caseLabels = actualCase.find_all("label")
                                            caseNumber = caseLabels[0].text
                                            caseType = caseLabels[2].text
                                            if ("-F-" in caseNumber or "-CR-" in caseNumber or "-M-" in caseNumber) and ("ARRAIGNMENT" in caseType or "PRELIMINARY HEARING" in caseType) and ("COMMONWEALTH" in caseLabels[1].text):
                                                case = Case()
                                                case.caseNumber = caseNumber
                                                case.county = county.split('/')[1]
                                                case.courtType = courtType.split('/')[0]
                                                case.date = day
                                                case.time = trialTime
                                                case.roomNumber = roomNumber

                                                try:
                                                    case.defendantName = caseLabels[1].text.split(" VS. ")[1].replace(",", "")
                                                except:
                                                    try:
                                                        case.defendantName = caseLabels[1].text.split(" VS.")[1].replace(",", "")
                                                    except:
                                                        case.defendantName = caseLabels[1].text.split(" VS ")[1].replace(",", "")

                                                case.hearingType = caseType
                                                if len(actualCase.find('table').find_all(recursive=False)):
                                                    for row in actualCase.find_all("tr"):
                                                        charge = ""
                                                        for column in row.find_all(recursive=False):
                                                            charge += str(" %s" % (column.text))
                                                        case.charges.append(charge.lstrip().replace(",", ""))
                                                if any(cK in '|'.join(case.charges) for cK in chargeKeys):
                                                    cases.append(case)

                                                    logger.info('Just added another case: '+ case.caseNumber +' - '+case.defendantName)
                                                    time.sleep(7)
                                            else:
                                                continue
            #with open("kcojDatabase2.csv", "a") as file:
            #    for case in cases:
            #        file.write('"%s","%s","%s","%s","%s","%s","%s","%s","%s"\n'.encode('utf-8') % (case.caseNumber, case.county, case.courtType, case.date, case.time, case.roomNumber, case.defendantName.encode('utf-8'), case.hearingType, '|'.join(case.charges)))
            logger.info('Saving in database...')
            for case in cases:
                    if session.query( Cases ).filter( Cases.caseNumber == case.caseNumber ).filter( Cases.county == case.county ).count() == 0:
                        session.add(Cases(case.caseNumber, case.county, case.courtType, case.date, case.time, case.roomNumber, case.defendantName.encode('utf-8'), case.hearingType, '|'.join(case.charges)))
                    print(case.caseNumber)
            session.commit()
            logger.info('Saved!')

    except Exception as e:
        #driver.save_screenshot('screenshots/screenshot_' + time.strftime("%d_%m_%Y") + '.png')
        logger.error('Error occured', exc_info=True)
    #driver.quit()
    logger.info('Script finished!')
    #vdisplay.stop()
    
if __name__ == '__main__':
    main()

